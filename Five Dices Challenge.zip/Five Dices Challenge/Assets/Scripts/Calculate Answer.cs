using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using static DiceAndComponents;

public class CalculateAnswer : Switchs
{
    public DiceAndComponents dice;
    private char operator_symbol { get; set; }
    public float answer { get; set; }
    float plusAnswer = 0f, subAnswer = 0f, multiAnswer = 1f, PosAnswer = 1;
    public float GetAnswers(int operator_symbol, List<int> ints)
    {
        answer = 0f;
        plusAnswer = subAnswer = 0f; multiAnswer = 1f; PosAnswer = 1;
        dice.answer = 0f;
        for (int value = 0; value < ints.Count; value++)
        {
            if (value == 0 && operator_symbol == 3)
            {
                PosAnswer = ints[value];
                dice.answer = GenerateAnswer(operator_symbol, ints[value]);
                PosAnswer = ints[0];
            }
            else
            {
                dice.answer = GenerateAnswer(operator_symbol, ints[value]);
            }
        }
        return dice.answer;
    }

    private float GenerateAnswer(int operator_symbol, int value)
    {
        answer = 0f;
        this.operator_symbol = switchOperator(operator_symbol);
        switch (this.operator_symbol)
        {
            case '+':
                {
                    plusAnswer += value;
                    answer = plusAnswer;
                    break;
                }
            case '-':
                {
                    subAnswer = (-subAnswer) - (-value);
                    answer = subAnswer;
                    break;
                }
            case '*':
                {
                    multiAnswer *= value;
                    answer = multiAnswer;
                    break;
                }
            case '/':
                {
                    PosAnswer /= value;
                    answer = PosAnswer;
                    break;
                }
        }
        // print(this.operator_symbol);

        return answer;
    }

    public float GenerateFakeAnswer(char operatorSymbol, float answer)
    {
        float fakeAnswer;
        System.Random random = new System.Random();
        float failAnswer = answer;
        switch (operatorSymbol)
        {
            case '+':
                {
                    int randomNum = random.Next(1, 6);
                    failAnswer += randomNum;
                    break;
                }
            case '-':
                {
                    int randomNum = random.Next(1, 6);
                    failAnswer -= randomNum;
                    break;
                }
            case '*':
                {
                    int randomNum = random.Next(1, 6);
                    failAnswer *= randomNum;
                    break;
                }
            case '/':
                {
                    int randomNum = random.Next(1, 6);
                    failAnswer /= randomNum;
                    break;
                }
        }

        fakeAnswer = failAnswer;
        return fakeAnswer;
    }

    public void GetScoresToPlayer(bool isAnswer)
    {
        if (isAnswer.Equals(true))
        {
            dice.scores++;
            dice.scores_text.text = dice.scores.ToString("#.##");
        }
    }

    public void ShowPanelScore(bool isActive)
    {
        dice.panel.SetActive(isActive);
        Time.timeScale = 0f;
        if (dice.total_correct > 0)
        {
            dice.percent_sign = dice.total_correct * 100 / dice.total_question;
        }
        dice.quiz_time_text.text = "Quiz Time: " + Mathf.Round(timer).ToString() + min.ToString("#:##");
        dice.score_text.text = "Score: " + dice.scores.ToString();
        dice.total_ques_text.text = "Total Questions: " + dice.total_question.ToString();
        dice.total_correct_text.text = "Total Correct: " + dice.total_correct.ToString();
        if (dice.percent_sign > 0 && dice.percent_sign < 1) dice.percent_text.text = dice.percent_sign.ToString("0.##") + "% Correct";
        else if (dice.percent_sign.Equals(0)) dice.percent_text.text = dice.percent_sign.ToString("0.0") + "% Correct";
        else dice.percent_text.text = dice.percent_sign.ToString("#.##") + "% Correct";
    }
}