using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class DiceAndComponents : MonoBehaviour
{
    // ---------------------------------- [Numbers] ----------------------------------
    [Header("Number Types")]
    public float answer;
    public float scores;
    public static float timer = 15f;
    public static float min = 60f;
    public float percent_sign = 0f;
    public int total_question = 0;
    public int total_correct = 0;
    public int number_of_dices = 2;
// ---------------------------------- [List] ----------------------------------
    [Header("List Types")]
    public List<int> number_list;
    public List<float> fail_answers;
// ---------------------------------- [Transform] ----------------------------------
    [Header("Transform Types")]
    public Transform dice_frame;
    public Transform two_dice_position, four_dice_position, six_dice_position;
// ---------------------------------- [Button] ----------------------------------
    [Header("Button Types")]
    public Button arrow_left;
    public Button arrow_right;
    public Button block1, block2;
    public Button home_button, hide_button, close_button;
    public Button tap_to_play;
// ---------------------------------- [Text] ----------------------------------
    [Header("Text Types")]
    public Text scores_text;
    public Text value_of_dices;
    public Text timer_text;
    public Text view_answer;
    public Text block1_text, block2_text;
    public Text quiz_time_text, score_text, total_ques_text, total_correct_text, percent_text;
// ---------------------------------- [Sprite] ----------------------------------
    [Header("Sprite Types")]
    public Sprite[] spritesDice;
    public Sprite hide_sprite, unhide_sprite, pause_sprite, play_sprite;
    public Sprite[] spritesOperator;
    public Sprite spriteEmpty;
// ---------------------------------- [Game Object] ----------------------------------
    [Header("Game Object Types")]
    public GameObject panel_answer;
    public GameObject pause_panel;
    public GameObject backObject;
    public GameObject panel;
// ---------------------------------- [Image] ----------------------------------
    [Header("Image Types")]
    public Image hid_image;
    public Image pause_image;
// ---------------------------------- [Animator] ----------------------------------
    [Header("Animator Types")]
    public Animator options_animate;
    public Animator back_animate;
// ---------------------------------- [Audios] ----------------------------------
    [Header("Object Types")]
    public AudioSettings audio;
}
