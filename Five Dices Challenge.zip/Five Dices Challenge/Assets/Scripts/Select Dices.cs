using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectDices : MonoBehaviour
{
    public DiceAndComponents dice;

    public void IncreaseDice()
    {
        SetEmptyDices(0, 2, 3, 5, 6, 8);
        dice.number_of_dices += 2;
        if (dice.number_of_dices.Equals(6))
        {
             
            dice.value_of_dices.text = dice.number_of_dices.ToString();
            dice.arrow_right.enabled = false;
            ControlDiceSelect(0, 1, 2, 3, 4, 5, 6, 7, 8);
            RectTransform rectTransform = dice.dice_frame.GetComponent<RectTransform>();
            Vector2 sizeDelta = rectTransform.sizeDelta;
            sizeDelta.y = 964f;
            rectTransform.sizeDelta = sizeDelta;
            dice.dice_frame.position = dice.six_dice_position.position;

        }
        else if (dice.number_of_dices.Equals(4))
        {
            dice.audio.sfxAudio[3].Play();
            dice.value_of_dices.text = dice.number_of_dices.ToString();
            dice.arrow_right.enabled = true;
            dice.arrow_left.enabled = true;
            ControlDiceSelect(0, 1, 2, 3, 4, 5);
            RectTransform rectTransform = dice.dice_frame.GetComponent<RectTransform>();
            Vector2 sizeDelta = rectTransform.sizeDelta;
            sizeDelta.y = 683f;
            rectTransform.sizeDelta = sizeDelta;
            dice.dice_frame.position = dice.four_dice_position.position;
        }
    }

    public void DecreaseDice()
    {
        SetEmptyDices(0, 2, 3, 5, 6, 8);
        dice.number_of_dices -= 2;
        if (dice.number_of_dices.Equals(2))
        {
            dice.audio.sfxAudio[3].Play();
            dice.value_of_dices.text = dice.number_of_dices.ToString();
            dice.arrow_left.enabled = false;
            ControlDiceSelect(0, 1, 2);
            RectTransform rectTransform = dice.dice_frame.GetComponent<RectTransform>();
            Vector2 sizeDelta = rectTransform.sizeDelta;
            sizeDelta.y = 417;
            rectTransform.sizeDelta = sizeDelta;
            dice.dice_frame.position = dice.two_dice_position.position;

        }
        else if (dice.number_of_dices.Equals(4))
        {
            dice.audio.sfxAudio[3].Play();
            dice.value_of_dices.text = dice.number_of_dices.ToString();
            dice.arrow_right.enabled = true;
            dice.arrow_left.enabled = true;
            ControlDiceSelect(0, 1, 2, 3, 4, 5);
            RectTransform rectTransform = dice.dice_frame.GetComponent<RectTransform>();
            Vector2 sizeDelta = rectTransform.sizeDelta;
            sizeDelta.y = 683f;
            rectTransform.sizeDelta = sizeDelta;
            dice.dice_frame.position = dice.four_dice_position.position;
        }
    }

    void SetEmptyDices(params int[] dices)
    {
        foreach (var item in dices)
        {
            for (int i = 0; i < dice.dice_frame.childCount; i++)
            {
                if (item.Equals(i))
                {
                    dice.dice_frame.GetChild(i).GetComponent<Image>().sprite = dice.spriteEmpty;
                }
            }
        }
    }

    void ControlDiceSelect(params int[] dices)
    {
        for (int i = 0; i < dice.dice_frame.childCount; i++)
        {
            dice.dice_frame.GetChild(i).gameObject.SetActive(false);
        }
        foreach (var item in dices)
        {
            for (int i = 0; i < dice.dice_frame.childCount; i++)
            {
                if (item.Equals(i))
                {
                    dice.dice_frame.GetChild(i).gameObject.SetActive(true);
                }
            }
        }

    }
}
