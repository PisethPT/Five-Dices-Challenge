using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Switchs: MonoBehaviour
{
    private char operator_symbol;
    public char switchOperator(int operators)
    {
        switch (operators)
        {
            case 0:
                {
                    operator_symbol = '+';
                    break;
                }
            case 1:
                {
                    operator_symbol = '-';
                    break;
                }
            case 2:
                {
                    operator_symbol = '*';
                    break;
                }
            case 3:
                {
                    operator_symbol = '/';
                    break;
                }
            default:
                break;
        }

        return operator_symbol;
    }


}
