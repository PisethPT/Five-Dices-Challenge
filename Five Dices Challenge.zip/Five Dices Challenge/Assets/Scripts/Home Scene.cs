using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HomeScene : MonoBehaviour
{
    public void HomeSceneLoad(){
        SceneManager.LoadScene("Five Dices Challenge");
    }
}
