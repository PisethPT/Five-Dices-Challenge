using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using static DiceAndComponents;

public class OtherButtonsController : ButtonDAO
{
    public DiceAndComponents dice;
    public CalculateAnswer calculateAnswer;
    public Buttons buttons;
    private bool isHide = false, isPause = false;

    public override void BackButton()
    {
        dice.audio.sfxAudio[3].Play();
        dice.options_animate.Play("open");
        dice.back_animate.Play("back");
        StartCoroutine(WaitClose(false, 1.25f));
    }

    public override void CloseButton()
    {
        dice.audio.sfxAudio[3].Play();
        dice.options_animate.Play("close");
        dice.back_animate.Play("undo");
        StartCoroutine(WaitClose(true, 0.1f));
    }

    public override void HideAndUnhideAnswer()
    {
        dice.audio.sfxAudio[3].Play();
        isHide = !isHide;
        if (isHide)
        {
            dice.panel_answer.SetActive(true);
            dice.hid_image.sprite = dice.unhide_sprite;
        }
        else if (!isHide)
        {
            dice.panel_answer.SetActive(false);
            dice.hid_image.sprite = dice.hide_sprite;
        }
    }

    public override void PauseButton()
    {
        dice.audio.sfxAudio[3].Play();
        isPause = !isPause;
        if (isPause)
        {
            dice.pause_image.sprite = dice.play_sprite;
            Time.timeScale = 0f;
            dice.close_button.enabled = false;
            dice.hide_button.enabled = false;
            dice.home_button.enabled = false;
            dice.pause_panel.SetActive(true);
        }
        else if (!isPause)
        {
            dice.pause_image.sprite = dice.pause_sprite;
            Time.timeScale = 1f;
            dice.close_button.enabled = true;
            dice.hide_button.enabled = true;
            dice.home_button.enabled = true;
            dice.pause_panel.SetActive(false);
        }
    }

    public override void Resume()
    {
        dice.audio.sfxAudio[3].Play();
        if (timer <= 0 && buttons.isTap == false)
        {
            Time.timeScale = 1f;
            min = 60f;
            timer = 15f;
            SceneManager.LoadScene("Five Dices Challenge");
        }
        else
        {
            dice.panel.SetActive(false);
            Time.timeScale = 1f;
        }
    }

    public void Scene()
    {
        dice.audio.sfxAudio[3].Play();
        calculateAnswer.ShowPanelScore(true);
    }

    public override void ToHome()
    {
        dice.audio.sfxAudio[3].Play();
        Time.timeScale = 1f;
        min = 60f;
        timer = 15f;
        dice.panel.SetActive(false);
        SceneManager.LoadScene("Home Scene");
    }

    IEnumerator WaitClose(bool isBool, float time)
    {
        yield return new WaitForSeconds(time);
        dice.backObject.SetActive(isBool);
    }

}
