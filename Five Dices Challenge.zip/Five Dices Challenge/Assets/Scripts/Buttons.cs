using System.ComponentModel;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Buttons : MonoBehaviour
{
    public Randoms randoms;
    public Text block1, block2;
    public bool isTap = false;
    public float chooseAnswer;
    private bool isAnswer;
    string your_answer;
    public void TapToPlay()
    {
        randoms.dice.audio.sfxAudio[0].Play();
        isTap = true;
        randoms.dice.total_question++;
        randoms.GetNumbers(randoms.dice.number_of_dices);
        ButtonsEnable(false, true);
    }

    public void ChooseAnswer()
    {
        isTap = false;
        your_answer = string.Empty;
        string blockName;
        string buttonName = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.name;
        switch (buttonName)
        {
            case "Block1":
                {
                    randoms.dice.audio.sfxAudio[0].Play();
                    blockName = block1.GetComponent<Text>().text;
                    float.TryParse(blockName, out chooseAnswer);

                    if (chooseAnswer < 1 && chooseAnswer > 0) your_answer = chooseAnswer.ToString("0.###");
                    else if (chooseAnswer.Equals(0)) your_answer = chooseAnswer.ToString("0");
                    else your_answer = chooseAnswer.ToString("#.###");
                    print("Your Answer: " + chooseAnswer);
                    break;
                }
            case "Block2":
                {
                    randoms.dice.audio.sfxAudio[0].Play();
                    blockName = block2.GetComponent<Text>().text;
                    float.TryParse(blockName, out chooseAnswer);
                    if (chooseAnswer < 1 && chooseAnswer > 0) your_answer = chooseAnswer.ToString("0.###");
                    else if (chooseAnswer.Equals(0)) your_answer = chooseAnswer.ToString("0");
                    else your_answer = chooseAnswer.ToString("#.###");
                    print("Your Answer: " + your_answer);
                    break;
                }
        }
        ButtonsEnable(false, false);
        isAnswer = CheckPlayerAnswer(your_answer);
        print("Your Answer Is " + isAnswer);
        randoms.calculateAnswer.GetScoresToPlayer(isAnswer);
        StartCoroutine(WaitUpdateGame());
    }

    private bool CheckPlayerAnswer(string your_answer)
    {
        if (string.Compare(randoms.string_view, your_answer) == 0)
        {
            randoms.dice.audio.sfxAudio[1].Play();
            randoms.dice.total_correct++;
            return true;
        }
        else
        {
            randoms.dice.audio.sfxAudio[2].Play();
            return false;
        }
    }

    public void ButtonsEnable(bool isEnable1, bool isEnable2)
    {
        randoms.dice.tap_to_play.enabled = isEnable1;
        randoms.dice.arrow_left.enabled = isEnable1;
        randoms.dice.arrow_right.enabled = isEnable1;

        randoms.dice.block1.enabled = isEnable2;
        randoms.dice.block2.enabled = isEnable2;
    }

    private IEnumerator WaitUpdateGame()
    {
        randoms.dice.block1_text.text = randoms.dice.block2_text.text = "0";
        yield return new WaitForSeconds(1.5f);
        ButtonsEnable(true, false);
        randoms.SetEmptySprites();
        randoms.dice.view_answer.text = "0";
    }

}
