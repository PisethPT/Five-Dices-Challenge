using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static DiceAndComponents;

public class Timer : MonoBehaviour
{
    public Buttons buttons;

    void Update()
    {
        if (buttons.isTap)
        {
            min -= Time.deltaTime;
            buttons.randoms.dice.timer_text.text = Mathf.Round(timer).ToString() + min.ToString("#:##");
            if (min <= 0)
            {
                min = 60f;
                timer--;
            }
            if (timer <= 0)
            {
                buttons.isTap = false;
                buttons.ButtonsEnable(false, false);
                buttons.randoms.calculateAnswer.ShowPanelScore(true);
            }
        }
    }
}
