using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class ButtonDAO : MonoBehaviour
{
    public abstract void BackButton();
    public abstract void CloseButton();
    public abstract void PauseButton();
    public abstract void HideAndUnhideAnswer();
    public abstract void Resume();
    public abstract void ToHome();
}
