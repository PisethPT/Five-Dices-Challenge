using System.Collections;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using UnityEngine;
using UnityEngine.UI;

public class Randoms : MonoBehaviour
{
    private char operator_symbol;
    public CalculateAnswer calculateAnswer;
    public DiceAndComponents dice;
    [HideInInspector] public float answer = 0f;
    [HideInInspector]  public string string_answer, string_fake, string_view;
    public void GetNumbers(int numberOfDices)
    {
        answer = 0f;
        dice.number_list.Clear();
        for (int i = 0; i < numberOfDices; i++)
        {
            int number = Random.Range(1, 7);
            dice.number_list.Add(number);
        }
        SetDicesSprite(numberOfDices);
        GetOperators(numberOfDices, dice.number_list);
    }

    void GetOperators(int numberOfDices, List<int> ints)
    {
        string_answer = string_fake = string_view = string.Empty;
        int operators = Random.Range(0, 4);
        SetOperatorsSprite(operators, numberOfDices);
        answer = calculateAnswer.GetAnswers(operators, ints);
        if (operators == 1)
        {
            answer = -answer;
        }
        // print("Answer: " + answer);
        ShuffleAnswer(answer);
        
        if(answer>0 && answer<1) string_view = answer.ToString("0.###");
        else if(answer.Equals(0)) string_view = "0";
        else string_view = answer.ToString("#.###");
        
        dice.view_answer.text = string_view;
    }

    void ShuffleAnswer(float answer)
    {
        List<float> ints = new List<float>();
        float fakeAnswer = 0f;
        char operator_symbol;
        int operators = Random.Range(0, 3);
        operator_symbol = calculateAnswer.switchOperator(operators);
        fakeAnswer = calculateAnswer.GenerateFakeAnswer(operator_symbol, answer);
        ints.Clear();
        for (int i = 0; i < 2; i++)
        {
            if (i == 0)
                ints.Add(answer);
            else if (i == 1)
                ints.Add(fakeAnswer);
        }
        Shuffle<float>(ints);

            if(answer>0 && answer<1)  string_answer = ints[0].ToString("0.###");
            else if(ints[0].Equals(0)) string_answer ="0";
            else string_answer = ints[0].ToString("#.###");


            if(answer>0 && answer<1) string_fake = ints[1].ToString("0.###");
            else if(ints[1].Equals(0)) string_fake ="0";
            else string_fake = ints[1].ToString("#.###");
            print("fake : "+string_fake);
            print("answer : "+string_answer);
            dice.block1_text.text = string_answer;
            dice.block2_text.text = string_fake;
        
    }

    private void Shuffle<T>(List<T> list)
    {
        System.Random random = new System.Random();

        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = random.Next(i + 1);
            T temp = list[i];
            list[i] = list[j];
            list[j] = temp;
        }
    }

    void SetOperatorsSprite(int operators, int numberOfDices)
    {
        int index = 0;
        List<int> diceIndex = new List<int>();
        if (numberOfDices == 2)
        {
            diceIndex = new List<int> { 1 };
        }
        else if (numberOfDices == 4)
        {
            diceIndex = new List<int> { 1, 4 };
        }
        else if (numberOfDices == 6)
        {
            diceIndex = new List<int> { 1, 4, 7 };
        }

        for (int i = 0; i < dice.spritesOperator.Length; i++)
        {
            if (operators.Equals(i))
            {
                for (int j = 0; j < diceIndex.Count; j++)
                {
                    dice.dice_frame.GetChild(diceIndex[index]).GetComponent<Image>().sprite = dice.spritesOperator[i];
                    index++;
                }
            }
        }
    }


    void SetDicesSprite(int numberOfDices)
    {
        int index = 0;
        List<int> diceIndex = new List<int>();
        if (numberOfDices == 2)
        {
            diceIndex = new List<int> { 0, 2 };
        }
        else if (numberOfDices == 4)
        {
            diceIndex = new List<int> { 0, 2, 3, 5 };
        }
        else if (numberOfDices == 6)
        {
            diceIndex = new List<int> { 0, 2, 3, 5, 6, 8 };
        }


        for (int i = 0; i < dice.number_list.Count; i++)
        {
            for (int j = 0; j < dice.spritesDice.Length; j++)
            {
                if ((dice.number_list[i] - 1) == j)
                {
                    dice.dice_frame.GetChild(diceIndex[index]).GetComponent<Image>().sprite = dice.spritesDice[j];
                    index++;

                }
            }
        }
    }

    public void SetEmptySprites(){
        for(int i = 0; i< dice.dice_frame.childCount; i++){
            dice.dice_frame.GetChild(i).GetComponent<Image>().sprite = dice.spriteEmpty;
        }
    }

}
