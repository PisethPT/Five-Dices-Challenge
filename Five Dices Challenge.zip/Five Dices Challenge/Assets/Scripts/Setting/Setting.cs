using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Setting : MonoBehaviour
{
    [Header("Animator Types")]
    public Animator setting;
    public Animator music;
    public Animator sfx;
    public Animator S;
    private bool isSetting = false, isMusic = false, isSFX = false;
    public void Settings()
    {
        isSetting = !isSetting;
        if (isSetting)
        {
            S.Play("settingOn");
            setting.Play("s_Open");
        }
        else if (!isSetting)
        {
            S.Play("settingOff");
            if (isSFX) { sfx.Play("sfx_Close"); isSFX = false;}
            if (isMusic) { music.Play("m_Close"); isMusic = false; }
            setting.Play("s_Close");
        }
    }

    public void Music()
    {
        isMusic = !isMusic;
        if (isMusic)
        {
            if (isSFX) { sfx.Play("sfx_Close"); isSFX = false; }
            music.Play("m_Open");
        }
        else if (!isMusic)
        {
            music.Play("m_Close");
        }
    }
    public void SFX()
    {
        isSFX = !isSFX;
        if (isSFX)
        {
            if (isMusic) { music.Play("m_Close"); isMusic = false;}
            sfx.Play("sfx_Open");
        }
        else if (!isSFX)
        {
            sfx.Play("sfx_Close");
        }
    }

}
